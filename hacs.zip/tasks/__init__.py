"""Init HACS tasks."""
